#! /bin/bash

#1.

#read -p "Enter the values of P, R and T : " p r t
#si=$(( $(($p*$r*$t)) / 100))
#echo "S.I. : " $si

#2.

#read -p "Enter Basic Salary : " bs
#dp=$(($bs / 2))
#da=$(($(($bs + $dp)) * 7/20))
#hra=$(($(($bs + $dp)) * 2/25))
#ma=$(($(($bs + $dp)) * 3/100))
#pf=$(($(($bs + $dp)) * 1/10))
#sl=$(($bs + $dp + $da + $hra + $ma - $pf))
#echo "Salary : " $sl 

#3.

#read -p "Enter three numbers : " a b c
#avg=$(($(($a + $b + $c))/3))
#echo "Average is : " $avg

#4.

#read -p "Enter two numbers : " a b
#echo -e "Sum : " $(($a + $b)) "\nSubtraction : " $(($a - $b)) "\nMultiplication : " $(( $a * $b )) "\nDivision : " $(( $a / $b))

#5.

#read -p "Enter marks of three subjects(out of 100) : " a b c
#avg=$(((($a + $b + $c))/3))
#if [ $avg -gt 50 ]
#then
#	echo "First class"
#elif [ $avg -ge 40 -a $avg -le 50 ]
#then
#	echo "Second class"
#else
#	echo "Fail"
#fi




